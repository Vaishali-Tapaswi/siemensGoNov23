package main
import "fmt"
import "errors"
type Driver interface{
	open()
	close()
}


type OracleDriver struct{
}
func (ora OracleDriver) close(){
	fmt.Println("OracleDriver close method")
}
func (ora OracleDriver) open(){
	fmt.Println("OracleDriver open method")
}
type MySQLDriver struct{
}
func (my MySQLDriver) open1(){
	fmt.Println("MySQLDriver open1 method")
}
func (my MySQLDriver) close(){
	fmt.Println("MySQLDriver close method")
}
func (my MySQLDriver) open(){
	fmt.Println("MySQLDriver open method")
}

func Connection(str string) (driver Driver, err error){
	if str=="ora"{
		driver = OracleDriver{}
	} else if str=="mysql"{
		driver =  MySQLDriver{}
	} else {
		err = errors.New("Invalid Driver Name")
	}
	return 
}
func main(){
	//var driver Driver
	driver,err := Connection("mysql")
	fmt.Println("Error  ", err)
	if (err != nil){
		fmt.Println("error = " , err)
		return
	}
	driver.open()
	driver.close()
}
/*
2 drivers
	1. OracleDriver
	2. MySQLDriver
	
interface Driver
	open
	close 
	
func Helper(str DriverName){
	if drivername == oracle
		return OracleDriver
	else
		return MySQLDriver
	*/