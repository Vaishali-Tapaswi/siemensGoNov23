package main
import (
	"github.com/gorilla/mux"
	"net/http"
	"fmt"
)
func main() {
	fmt.Println("startin main")
    r := mux.NewRouter()
    r.HandleFunc("/", HomeHandler)
	r.HandleFunc("/emp", EmpHandler).Methods("GET")
 	err := http.ListenAndServe(":8080", r)
	 fmt.Println("err" , err)
}
 func HomeHandler(response http.ResponseWriter, request *http.Request){
	fmt.Fprintln(response, "<h1>Index Page</h1><a href = '/emp'>Emp Handler</a>")
 }
 func EmpHandler(response http.ResponseWriter,request *http.Request){
	fmt.Fprintln(response, "<h1>Emp Handler</h1>")
}