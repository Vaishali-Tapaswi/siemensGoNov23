package main
import (
	"fmt"
	"time"
)
func main(){
	fmt.Println("start of main")
	
	go print("-",500) 
	go print("*",500) 
	
	fmt.Println("end of main") 
	// 3 options to stop main method 
//	for{}
	time.Sleep(1 * time.Second)
//	scan -> stop to accept some input
}


func print(str string, cnt int){
	for i:=0; i<cnt;i++{
		fmt.Print(str, "  ")
	}
}
