package main
import (
	"fmt"
	"encoding/json"
	"net/http"
	"os"
	"io"
)
type User struct {
	Data struct {
		ID        int    `json:"id"`
		Email     string `json:"email"`
		FirstName string `json:"first_name"`
		LastName  string `json:"last_name"`
		Avatar    string `json:"avatar"`
	} `json:"data"`
	Support struct {
		URL  string `json:"url"`
		Text string `json:"text"`
	} `json:"support"`
}
func main(){
	resp, err := http.Get("https://reqres.in/api/users/"+ os.Args[1])
	if err != nil {
			return
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	//Unmarshal(data []byte, v any) error
	user := User{}
	err = json.Unmarshal(body, &user)
	fmt.Println(" Error = ", err)
	fmt.Println(" User Email  = ", user.Data.Email)
	
}
