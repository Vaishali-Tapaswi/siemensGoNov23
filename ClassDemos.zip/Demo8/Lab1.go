package main
import (
	"fmt"
	"strconv"
)
func add(i,j int)int{
	fmt.Println("add invoked with " , i ," and " ,j)
	return i+j
}
func divide(str1,str2 string) int {
	no1,_ := strconv.Atoi(str1)
	no2,_ := strconv.Atoi(str2)
	return no1/no2
}
func main(){
	fmt.Println("add of 10 and 10 is " , add(10,10))
	fmt.Println("divide of 100 and 10 is " , divide("100","10"))
	fmt.Println("divide of a and 10 is " , divide("a","10"))
	fmt.Println("divide of 100 and a is " , divide("100","a"))
}