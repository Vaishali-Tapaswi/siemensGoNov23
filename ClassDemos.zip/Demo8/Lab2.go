package main

import (
    "fmt"
)
type Emp struct{}
func (c *Emp) modify(key,value string)string{
	fmt.Println("Connecting to Postgres server to get data from Emp")
	return value
}

func main() {
    fmt.Println("Hello World")
	e := Emp{}
	e.modify("appname","Lab8")
	
}