package dblib
import (
	"database/sql"
	_ "github.com/lib/pq"
	"github.com/magiconair/properties"
)
func readprop() (conn string){
	p := properties.MustLoadFile("db.properties", properties.UTF8)
	return p.MustGetString("url")
}

func getDb() (db *sql.DB, err error) {
	db, err = sql.Open("postgres",  readprop())
	return
}