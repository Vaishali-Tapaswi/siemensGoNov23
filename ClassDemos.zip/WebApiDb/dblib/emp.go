package dblib
type Emp struct {
	Empno  int `json:"empno"`
	Ename  string `json:"ename"`
	Salary int `json:"salary"`
}