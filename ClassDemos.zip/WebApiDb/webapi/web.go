package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"github.com/dblib"
)
func main() {
	empdb:= dblib.EmpDb{}
	http.HandleFunc("/emp",
		func(w http.ResponseWriter, r *http.Request) {
			fmt.Println("in handlefunc of emp, method =  ", r.Method)
			switch r.Method {
		/*	case "GET":
			
			//	bytes, _ := json.Marshal(empslice)
				w.Write(bytes) */
			case "POST":
				decoder := json.NewDecoder(r.Body)
				var emp dblib.Emp
				_ = decoder.Decode(&emp)
				//empdb := dblib.EmpDb{}
				err := empdb.Create(emp)
				fmt.Println("in post ", err)
			default:
				fmt.Println("in default")
				fmt.Fprintf(w, "default, %q", r.URL.Path)
			}
		})

	http.ListenAndServe(":8080", nil)
}