package main
import (
	"fmt"
	)
func main(){
   no1, no2 := 200, 4000
   fmt.Println("No1 = " , no1 , " No2 = " , no2)
   ans := no1 + no2
   fmt.Printf("Ans = %d ", ans)
/*
   var no1, no2 int
   no1 = 200
   no2 = 4000
   fmt.Println("No1 = " , no1 , " No2 = " , no2)
   var ans = no1 + no2;
   fmt.Printf("Ans = %d ", ans)
*/
}

	