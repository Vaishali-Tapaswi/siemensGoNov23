package main
import "fmt"
func adder() func(int) int {
	fmt.Println("Adder invoked ")
	sum := 0
	return func(x int) int {
		fmt.Println("in return function")
		sum += x
		return sum
	}
}

func main(){
	fnref := adder()
	fmt.Println(fnref)
	fmt.Println(fnref(10))
	fmt.Println(fnref(10))
	fmt.Println(fnref(10))
	fmt.Println(fnref(10))
	
}