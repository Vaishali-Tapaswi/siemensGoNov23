package main
import (
	"fmt"
)
func main(){
	str := "Simple"
	defer fmt.Println(str, "  1")
	fmt.Println("2")
	m1()
	fmt.Println("3")
	str = "Complex"
	fmt.Println(str, "  1")
	fmt.Println("4")
}

func m1(){
	defer fmt.Println("m1- defer -line")

	fmt.Println("m1 - 1")
	fmt.Println("m1 - 2")
}