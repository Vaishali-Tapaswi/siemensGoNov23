package main
import (
	"fmt"
	)
func main(){
    p1 := Point{10,50}
	fmt.Println("p1 = "  , p1)
	p1 = Point{Y:10}
	fmt.Println("p1 = "  , p1)
	p1.X = 400
	fmt.Println("p1 = "  , p1)
	p1.shift(11,22)
	fmt.Println("in main after shift p1 = "  , p1)
	p1.print()
	}

type Point struct {
	X int
	Y int
}
func (p *Point) shift( x int, y int) {
	fmt.Println("Start of Shift ", p)
	p.X += x 
	p.Y += y
	fmt.Println("End of Shift ", p)
}
func (p1 Point) print(){
	fmt.Printf("Point - x = %d, y = %d", p1.X, p1.Y)
}

/*
func shift(p Point, x int, y int) {
	fmt.Println("Start of Shift ", p)
	p.X += x 
	p.Y += y
	fmt.Println("End of Shift ", p)
}
*/
