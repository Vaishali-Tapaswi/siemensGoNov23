package main
import "fmt"
func main(){
	primes := [6]int{2, 3, 5, 7, 11, 13}
	fmt.Println(primes)
	primes[1] = 300
	fmt.Println(primes)
	fmt.Printf("primes is of %T \n\n", primes)
//	primes[9] = 4000
	fmt.Println(len(primes))
	
}