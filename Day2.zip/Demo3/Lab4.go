package main

import "fmt"

func main() {

	var m map[string] int
	m = make(map[string] int)
	m["a"] = 100
	m["b"] = 200
	m["a"] = 300
	fmt.Println(m["a"])
	fmt.Println(m)
	var m1 = map[string]int{
		"a": 10,
		"b": 20,
		"c": 30,
	}
	fmt.Println(m1)

}
