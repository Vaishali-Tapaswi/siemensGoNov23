package main
import (
    "fmt"
	"strconv"
	"time"
	"math/rand"
)
// Create two go routines, 1 for reading other for writing. 
func main() {
    fmt.Println("start of main")
    ch := make(chan string,10)
	go writer(ch, "Hello")
	go reader(ch)
	for{}
}
func reader(ch chan string) {
	for str := range ch{
		fmt.Println("in reader Received : " + str)
		str := strconv.Itoa(rand.Intn(1000))+"ms"
		dur,_ := time.ParseDuration(str)
		time.Sleep(dur)
	}	 
 }
func writer(ch chan string,str string) {
   for i:=1;i<=10;i++{
		fmt.Println(" in writer  " ,str ," ", i)
		ch <- "Writer sending  " + strconv.Itoa(i) 
		str := strconv.Itoa(rand.Intn(1000))+"ms"
		dur,_ := time.ParseDuration(str)
		time.Sleep(dur)
	}
	close(ch)
}

