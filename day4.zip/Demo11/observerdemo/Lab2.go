package main
import "fmt"
type Stock struct{
	symbol string;
	price int;
	investors []IInvestor
}
func (stock *Stock) Attach(investor IInvestor){
	stock.investors = append(stock.investors, investor)
}
func (stock *Stock) Detach(investor IInvestor){
	for i,v := range stock.investors{
		if (v.GetName() == investor.GetName()){
			stock.investors=append(stock.investors[0:i], stock.investors[i+1:]...)
			break
		}
	}
}
func (stock Stock) Notify(){
	for _,v := range stock.investors{
			v.Update(stock);
		}
		fmt.Println("")
	}
func (stock Stock)	ModifyPrice(value int){
	if (stock.price != value)	{
		stock.price = value
		stock.Notify();
	}
}
type IInvestor interface{
	Update(stock Stock)
	GetName() string
}
type Investor struct{
	name string
	stock Stock
}
func (inv Investor) Update(stock Stock){
	fmt.Println("Notified",inv.name, " of " , stock.symbol,"'s " ,	"change to ", stock.price)
}
func (inv Investor) GetName() string{
	return inv.name
}

func main(){
	 ibm := Stock{symbol:"IBM",price:100}
	 ibm.Attach(Investor{name:"Sorros"});
	ibm.Attach(Investor{name:"Berkshire"});
	// Fluctuating prices will notify investors
	ibm.ModifyPrice(121);
	ibm.ModifyPrice(151);
	
}