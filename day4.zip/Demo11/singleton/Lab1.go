package main
import (
	"fmt"
	"mylib"
)

func main(){
	s1 := mylib.GetInstance()
	fmt.Println("s1 " , s1.Add())
	fmt.Println("s1 " , s1.Add())
	fmt.Println("s1 " , s1.Add())
	fmt.Println("s1 " , s1.Add())
	fmt.Println("s1 " , s1.Add())
	s2 := mylib.GetInstance()
	fmt.Println("s2 " , s2.Add())
	fmt.Println("s2 " , s2.Add())
}