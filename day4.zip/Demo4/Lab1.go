package main
import (
	"fmt"
	//"properties"
	"github.com/magiconair/properties"
)
func main(){
		// init from a file
		p := properties.MustLoadFile("demo.properties", properties.UTF8)
		host := p.MustGetString("host")
		port := p.GetInt("port", 8080)
		fmt.Println("Host = " , host )
		fmt.Println("Port = " , port )

}