package main
import (
	"fmt"
	"time"
	"sync"
)
type Bank struct{
	Mu sync.Mutex
	Bal int
}
func main(){
	fmt.Println("start of main")
	bank := Bank{}
	go deposit(&bank, 50)
	go widraw(&bank, 50)
	time.Sleep(15 * time.Second)
	fmt.Println("end of main, current balance = " , bank.Bal) 

}

func deposit(bank *Bank, cnt int){
	for i:=0; i<cnt;i++{
		bank.Mu.Lock()
		curbal := bank.Bal + 1
		fmt.Println("in deposit - current balance is  ", bank.Bal)
		time.Sleep(15 * time.Millisecond)
		bank.Bal = curbal
		bank.Mu.Unlock()
	}
}

func widraw(bank *Bank, cnt int){
	for i:=0; i<cnt;i++{
		bank.Mu.Lock()
		curbal := bank.Bal - 1
		fmt.Println("in widraw - current balance is  ", bank.Bal)
		time.Sleep(100 * time.Millisecond)
		bank.Bal = curbal
		bank.Mu.Unlock()
	}
}