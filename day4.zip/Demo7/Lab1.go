package main
import (
	"fmt"
	"encoding/json"
)
type Emp struct{
	Empno int `json:"eno"`
	Ename string `json:"empname"`
	Salary int `json:"salary"`
}
func main(){
	e1 := Emp{1,"One",1111}
	bytes, err := json.Marshal(e1)
	fmt.Println("Bytes =  ", string(bytes), ", Error = ", err)
}