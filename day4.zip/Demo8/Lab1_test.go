package main
import (
//	"fmt"
	"testing"
)


func TestAdd(t *testing.T){
	got := add(10,10)
    if got != 20 {
        t.Errorf("add(10,20) = %d; want 20", got)
    }
}

func TestDivide(t *testing.T){
	got := divide("100","10")
    if got != 10 {
        t.Errorf("divide(100,10) = %d; want 10", got)
    }
}
func TestDivide1(t *testing.T){
	got := divide("a","10")
    if got != 0 {
        t.Errorf("divide('a',10) = %d; want 0", got)
    }
}
func TestDivide0(t *testing.T){
	// divide by 0 -> panic
	defer func() {
        if r := recover(); r == nil {
            t.Errorf("divide('10','0') has not given panic")
        }
    }()

	divide("10","0")
   
}