package calc
func Add(n1 int, n2 int) int {
	return n1+ n2
}
	