package dblib
import (
	
	"fmt"
	"strconv"
)
type EmpDb struct{}
func (empdb *EmpDb) Create(emp Emp) (err error){
	db, err := getDb()
	defer db.Close()	
	str := "INSERT INTO emp(empno, ename, salary) VALUES(" + strconv.Itoa(emp.Empno) + ",'" + emp.Ename 	+ "'," +  strconv.Itoa(emp.Salary) + ")"
	fmt.Println("create " , str)
	rowcnt, err := db.Exec(str)
	fmt.Println("Number of rows inserted ",rowcnt, ", \nerror  = " , err, "\n\n")
	return

}


